package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.AudioPlaybackState
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
val reminderIntent = Intent(this, ReminderBroadcastReceiver::class.java)
val pendingIntent = android.app.PendingIntent.getBroadcast(
    this, 0, reminderIntent, 
    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
)
alarmManager.setRepeating(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), 60000, pendingIntent)

        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent()
                }
            }
        }
    }
}

// --- COLOR ASSIGNMENTS matching "High Density" Theme ---
val DensityBg = Color(0xFFF4F9F1)
val DensityPrimary = Color(0xFF143D2A) // Deep Mosque Emerald
val DensitySageSub = Color(0xFF2A7E62) // Calm Sage
val DensityCardBg = Color(0xFFFFFFFF)
val DensityAccentGold = Color(0xFFC59B27) // Warm Gold
val DensityProgressCardBg = Color(0xFFE1EDD9) // Dynamic high light green

@Composable
fun MainAppContent() {
    val viewModel: MainViewModel = viewModel()
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DensityBg
    ) {
        Crossfade(targetState = loggedInUser) { user ->
            if (user == null) {
                AuthScreen(viewModel)
            } else {
                AppScaffoldContainer(viewModel = viewModel, modifier = Modifier.navigationBarsPadding())
            }
        }
    }
}

// --- 1. AUTH SCREEN ---
@Composable
fun AuthScreen(viewModel: MainViewModel) {
    val isLoad by viewModel.isAuthLoading.collectAsState()
    val err by viewModel.loginError.collectAsState()

    var isSignUpMode by remember { mutableStateOf(false) }
    var isForgotPasswordMode by remember { mutableStateOf(false) }

    var emailInput by remember { mutableStateOf("ahmedaljubari3@gmail.com") }
    var nameInput by remember { mutableStateOf("أحمد الجباري") }
    var passwordInput by remember { mutableStateOf("••••••••") }

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DensityPrimary, DensitySageSub)
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .statusBarsPadding()
                .imePadding()
                .testTag("auth_card"),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = DensityCardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(28.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Circular Crescent/Mosque Icon Design
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(DensityBg),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🕌", fontSize = 36.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "رفيق الطاعة",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DensityPrimary,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = "متابعة العبادات وتنافس صالحين هادف",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = DensitySageSub,
                        fontWeight = FontWeight.Medium
                    ),
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                if (isForgotPasswordMode) {
                    Text(
                        text = "استعادة كلمة المرور",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = DensityPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("البريد الإلكتروني") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.recoverPassword(emailInput) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("recover_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                        shape = RoundedCornerShape(16.dp),
                        enabled = !isLoad
                    ) {
                        Text("إرسال رابط الاستعادة")
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    TextButton(onClick = { isForgotPasswordMode = false }) {
                        Text("العودة لتسجيل الدخول", color = DensitySageSub, fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Text(
                        text = if (isSignUpMode) "إنشاء حساب جديد" else "تسجيل الدخول",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = DensityPrimary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("الإسم ثلاثي") },
                            leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, tint = DensitySageSub) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("البريد الإلكتروني") },
                        leadingIcon = { Icon(Icons.Rounded.Email, contentDescription = null, tint = DensitySageSub) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("كلمة المرور") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = DensitySageSub) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { isForgotPasswordMode = true }) {
                            Text("نسيت كلمة المرور؟", color = DensitySageSub, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (err != null) {
                        Text(
                            text = err ?: "",
                            color = Color.Red,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Button(
                        onClick = {
                            if (isSignUpMode) {
                                viewModel.signUp(emailInput, nameInput)
                            } else {
                                viewModel.login(emailInput, nameInput)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_auth_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                        shape = RoundedCornerShape(16.dp),
                        enabled = !isLoad
                    ) {
                        if (isLoad) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Text(if (isSignUpMode) "تأكيد الاشتراك البدئي" else "دخول آمن")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            viewModel.login("ahmedaljubari3@gmail.com", "أحمد الجباري")
                            Toast.makeText(context, "تم تسجيل الدخول السريع عبر Google", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DensityPrimary),
                        border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.5f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Face, contentDescription = null, modifier = Modifier.padding(end = 8.dp), tint = DensityAccentGold)
                            Text("تسجيل سريع بحساب Google")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TextButton(onClick = { isSignUpMode = !isSignUpMode }) {
                        Text(
                            text = if (isSignUpMode) "لديك حساب بالفعل؟ سجل الدخول" else "ليس لديك حساب؟ سجل معنا ببريد إلكتروني",
                            color = DensitySageSub,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

// --- 2. SCAFFOLD WITH NAVIGATION ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffoldContainer(
    viewModel: MainViewModel,
    profile: UserProfile,
    currentScreen: Screen
) {
    val showBadge by viewModel.showNotificationBadge.collectAsState()
    var showNotifDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "رفيق الطاعة",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DensityPrimary
                            )
                        )
                        IslamicDateHeader()
                    }
                },
                actions = {
                    IconButton(onClick = {
                        showNotifDialog = true
                        viewModel.showNotificationBadge.value = false
                    }) {
                        Box {
                            Icon(Icons.Rounded.NotificationsActive, contentDescription = "الإشعارات", tint = DensityPrimary)
                            if (showBadge) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(DensityAccentGold)
                                        .align(Alignment.TopEnd)
                                )
                            }
                        }
                    }
                    IconButton(onClick = { viewModel.currentScreen.value = Screen.Settings }) {
                        Icon(Icons.Rounded.AccountCircle, contentDescription = "الملف الشخصي", tint = DensityPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DensityBg)
            )
        },
        bottomBar = {
            BottomNavigationBar(viewModel, currentScreen)
        },
        containerColor = DensityBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.Home -> HomeScreen(viewModel, profile)
                Screen.Counters -> CountersScreen(viewModel, profile)
                Screen.Library -> LibraryScreen(viewModel)
                Screen.Social -> FriendsAndSocialScreen(viewModel, profile)
                Screen.Groups -> GroupsAndChallengesScreen(viewModel, profile)
                Screen.Reports -> ReportsAndStatsScreen(viewModel, profile)
                Screen.Settings -> SettingsScreen(viewModel, profile)
                else -> HomeScreen(viewModel, profile)
            }
        }
    }

    if (showNotifDialog) {
        NotificationsDialog(viewModel) { showNotifDialog = false }
    }
}

@Composable
fun IslamicDateHeader() {
    val formatHijri = "١٤ شوال ١٤٤٧ هـ"
    val formatGreg = "٢٤ مايو ٢٠٢٦ م"
    Text(
        text = "$formatHijri | $formatGreg",
        style = MaterialTheme.typography.bodySmall.copy(
            color = DensitySageSub,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    )
}

@Composable
fun BottomNavigationBar(viewModel: MainViewModel, currentScreen: Screen) {
    NavigationBar(
        containerColor = DensityCardBg,
        tonalElevation = 8.dp,
        modifier = Modifier.height(72.dp)
    ) {
        val navItems = listOf(
            Triple(Screen.Home, "الرئيسية", Icons.Rounded.Home),
            Triple(Screen.Counters, "العدادات", Icons.Rounded.TripOrigin),
            Triple(Screen.Library, "المكتبة", Icons.Rounded.Book),
            Triple(Screen.Groups, "المجموعات", Icons.Rounded.GroupWork),
            Triple(Screen.Social, "المتابعين", Icons.Rounded.People),
            Triple(Screen.Reports, "الإحصاء", Icons.Rounded.BarChart),
            Triple(Screen.Settings, "الإعدادات", Icons.Rounded.Settings)
        )

        navItems.forEach { (screen, label, icon) ->
            val isSelected = currentScreen::class == screen::class
            NavigationBarItem(
                selected = isSelected,
                onClick = { viewModel.currentScreen.value = screen },
                icon = {
                    Icon(
                        icon,
                        contentDescription = label,
                        tint = if (isSelected) DensityPrimary else DensitySageSub.copy(alpha = 0.6f)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) DensityPrimary else DensitySageSub.copy(alpha = 0.6f)
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = DensityBg
                )
            )
        }
    }
}

// --- 3. NOTIFICATIONS DIALOG ---
@Composable
fun NotificationsDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    val notifications by viewModel.allNotificationsFlow.collectAsState(initial = emptyList())

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DensityCardBg),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "التنبيهات والتحفيزات",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = DensityPrimary
                    )
                    TextButton(onClick = { viewModel.clearNotifications() }) {
                        Text("مسح الكل", color = Color.Red, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (notifications.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🔔", fontSize = 40.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("علبة التنبيهات فارغة حالياً.", color = DensitySageSub, fontSize = 13.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(notifications) { item ->
                            val icon = when (item.type) {
                                "CHEER" -> "📣"
                                "CONGRATS" -> "⭐"
                                "REMINDER" -> "⏱️"
                                else -> "✨"
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DensityBg, RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(icon, fontSize = 16.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        item.text,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                        color = DensityPrimary
                                    )
                                    Text(
                                        "منذ قليل",
                                        style = MaterialTheme.typography.labelSmall.copy(color = DensitySageSub, fontSize = 9.sp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary)
                ) {
                    Text("إغلاق")
                }
            }
        }
    }
}

// --- 4. SCREEN: HOME ---
@Composable
fun HomeScreen(viewModel: MainViewModel, profile: UserProfile) {
    val tasks by viewModel.allTasksFlow.collectAsState(initial = emptyList())
    val completions by viewModel.currentCompletions.collectAsState()
    val quote by viewModel.motivationalQuote.collectAsState()
    val isQuoteLoad by viewModel.isQuoteLoading.collectAsState()

    var showAddTaskDialog by remember { mutableStateOf(false) }

    val completedCount = completions.count { it.isDone || it.completedCount > 0 }
    val totalCount = tasks.size
    val progressPercent = if (totalCount > 0) (completedCount.toFloat() / totalCount.toFloat() * 100).roundToInt() else 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Motivation Box
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.2f)),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(DensityPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isQuoteLoad) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Text("✨", fontSize = 20.sp)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "تحفيز اليوم السحابي",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = DensitySageSub
                            )
                            IconButton(
                                onClick = { viewModel.generateMotivationalQuote() },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = "تحديث", tint = DensityAccentGold, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(
                            text = quote,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontStyle = FontStyle.Normal,
                                lineHeight = 18.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }

        // Daily Progress Card with Radial Circle progress
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = DensityProgressCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "إنجاز اليوم المترابط",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = DensityPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تسهيل الطاعات وتقرب الزلفى",
                            style = MaterialTheme.typography.bodySmall,
                            color = DensitySageSub
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "تم إكمال $completedCount من $totalCount من الطاعات المقررة",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            color = DensityPrimary
                        )
                    }

                    // Circular Progress Canvas
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val progressSweep = (progressPercent.toFloat() / 100f) * 360f
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(
                                color = Color.White.copy(alpha = 0.5f),
                                style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = DensityPrimary,
                                startAngle = -90f,
                                sweepAngle = progressSweep,
                                useCenter = false,
                                style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$progressPercent%",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black),
                                color = DensityPrimary
                            )
                            Text(
                                text = "🔥 ${profile.consecutiveDays} أيام",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                color = DensityPrimary
                            )
                        }
                    }
                }
            }
        }

        // Prayers Quick Check
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الصلوات الخمس المفروضة اليوم",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DensityPrimary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                val prayerNames = listOf("فجر" to 1, "ظهر" to 2, "عصر" to 3, "مغرب" to 4, "عشاء" to 5)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    prayerNames.forEach { (name, taskId) ->
                        val existingComp = completions.find { it.taskId == taskId }
                        val isChecked = existingComp?.isDone == true

                        val bg = if (isChecked) DensityPrimary else Color.White
                        val textColor = if (isChecked) Color.White else DensityPrimary
                        val iconCode = if (isChecked) "✓" else ""

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(bg)
                                .border(1.dp, DensitySageSub.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                .clickable {
                                    val currentTask = tasks.find { it.id == taskId } ?: DailyTask(
                                        id = taskId,
                                        name = name,
                                        category = "صلاة",
                                        isSystem = true
                                    )
                                    viewModel.toggleWorshipCompletion(currentTask, !isChecked, 1)
                                }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textColor
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(if (isChecked) Color.White.copy(alpha = 0.2f) else DensityBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        iconCode,
                                        fontSize = 10.sp,
                                        color = if (isChecked) Color.White else DensitySageSub,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // List of duties
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "أوراد اليوم والعبادات اليومية",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DensityPrimary
                )
                TextButton(onClick = { showAddTaskDialog = true }) {
                    Text("+ إضافة عمل مخصص", color = DensitySageSub, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        val filteredTasks = tasks.filter { it.category != "عداد" && it.id > 5 }
        if (filteredTasks.isEmpty()) {
            item {
                Text(
                    "لا توجد عبادات مضافة حالياً.",
                    color = DensitySageSub,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            items(filteredTasks) { task ->
                val comp = completions.find { it.taskId == task.id }
                val isDone = comp?.isDone == true

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DensitySageSub.copy(alpha = 0.1f), RoundedCornerShape(16.dp)),
                    onClick = {
                        viewModel.toggleWorshipCompletion(task, !isDone, 1)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (task.category) {
                                            "صلاة" -> Color(0xFFE3F2FD)
                                            "أذكار" -> Color(0xFFFFF3E0)
                                            "قرآن" -> Color(0xFFE8F5E9)
                                            else -> Color(0xFFF3E5F5)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (task.category) {
                                        "صلاة" -> "🕌"
                                        "أذكار" -> "📿"
                                        "قرآن" -> "📖"
                                        else -> "🤍"
                                    },
                                    fontSize = 16.sp
                                )
                            }

                            Column {
                                Text(
                                    task.name,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = DensityPrimary
                                )
                                Text(
                                    task.category,
                                    fontSize = 10.sp,
                                    color = DensitySageSub
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!task.isSystem) {
                                IconButton(onClick = { viewModel.removeCustomTask(task.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = Color.Red.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
                                }
                            }

                            Checkbox(
                                checked = isDone,
                                onCheckedChange = { viewModel.toggleWorshipCompletion(task, !isDone, 1) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = DensityPrimary,
                                    uncheckedColor = DensitySageSub.copy(alpha = 0.4f)
                                )
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    if (showAddTaskDialog) {
        AddCustomTaskDialog(viewModel) { showAddTaskDialog = false }
    }
}

// --- 5. SCREEN: INTERACTIVE COUNTERS ---
@Composable
fun CountersScreen(viewModel: MainViewModel, profile: UserProfile) {
    val tasks by viewModel.allTasksFlow.collectAsState(initial = emptyList())
    val completions by viewModel.currentCompletions.collectAsState()

    val counterTasks = tasks.filter { it.category == "عداد" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "السبحة الإلكترونية والعدادات المباركة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
            Text(
                "حافظ على رطوبة لسانك بذكر الرحمن وراقب أهدافك اليومية المستدامة.",
                style = MaterialTheme.typography.bodySmall,
                color = DensitySageSub,
                modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
        }

        items(counterTasks) { task ->
            val comp = completions.find { it.taskId == task.id }
            val currentCount = comp?.completedCount ?: 0
            val target = viewModel.getTargetForCounter(task.id)
            val progress = if (target > 0) (currentCount.toFloat() / target.toFloat()).coerceAtMost(1f) else 0f

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DensitySageSub.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("📿", fontSize = 24.sp)
                            Column {
                                Text(
                                    task.name,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = DensityPrimary
                                )
                                Text(
                                    "الهدف اليومي المرجو: $target مرة",
                                    fontSize = 10.sp,
                                    color = DensitySageSub
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                viewModel.toggleWorshipCompletion(task, false, 0)
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Rounded.Loop, contentDescription = "تصفير العداد", tint = Color.Red.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "$currentCount / $target",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                ),
                                color = DensityPrimary
                            )
                            Text(
                                text = "نسبة الإنجاز: ${(progress * 100).roundToInt()}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = DensitySageSub
                            )
                        }

                        // Circular large tactile tap button
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(DensityPrimary)
                                .clickable {
                                    viewModel.incrementCounter(task)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("+", fontSize = 28.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = DensityPrimary,
                        trackColor = DensityBg
                    )
                }
            }
        }
    }
}

// --- 6. SCREEN: ISLAMIC LIBRARY (QURAN, AZKAR WITH TAP INITIATIVE) ---
@Composable
fun LibraryScreen(viewModel: MainViewModel) {
    val activeSurah by viewModel.activeSurah.collectAsState()
    val activeAzkarCategory by viewModel.activeAzkarCategory.collectAsState()
    val activeZikrTapCounts by viewModel.activeZikrTapCounts.collectAsState()
    val activeBook by viewModel.activeBook.collectAsState()

    var activeTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = DensityBg,
            contentColor = DensityPrimary
        ) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0; viewModel.selectSurah(null); viewModel.selectAzkarCategory(null); viewModel.selectBook(null) }) {
                Text("سُوَر المصحف", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp), fontSize = 12.sp)
            }
            Tab(selected = activeTab == 1, onClick = { activeTab = 1; viewModel.selectSurah(null); viewModel.selectAzkarCategory(null); viewModel.selectBook(null) }) {
                Text("حصن الأذكار", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp), fontSize = 12.sp)
            }
            Tab(selected = activeTab == 2, onClick = { activeTab = 2; viewModel.selectSurah(null); viewModel.selectAzkarCategory(null); viewModel.selectBook(null) }) {
                Text("المراجع والكتب", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp), fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                0 -> {
                    if (activeSurah != null) {
                        SurahReaderView(surah = activeSurah!!, viewModel = viewModel) { viewModel.selectSurah(null) }
                    } else {
                        SurahListView { viewModel.selectSurah(it) }
                    }
                }
                1 -> {
                    if (activeAzkarCategory != null) {
                        AzkarCounterView(
                            category = activeAzkarCategory!!,
                            countsMap = activeZikrTapCounts,
                            onTap = { viewModel.tapZikr(it) }
                        ) { viewModel.selectAzkarCategory(null) }
                    } else {
                        AzkarCategorySelector { viewModel.selectAzkarCategory(it) }
                    }
                }
                2 -> {
                    if (activeBook != null) {
                        BookChapterView(book = activeBook!!) { viewModel.selectBook(null) }
                    } else {
                        BooksListView { viewModel.selectBook(it) }
                    }
                }
            }
        }
    }
}

// --- 7. SCREEN: SOCIAL & TEAMS TRACKING ---
@Composable
fun FriendsAndSocialScreen(viewModel: MainViewModel, profile: UserProfile) {
    val friends by viewModel.allFriendsFlow.collectAsState(initial = emptyList())
    val emailInput by viewModel.addFriendEmailInput.collectAsState()

    val context = LocalContext.current

    val acceptedFriends = friends.filter { it.isAccepted }
    val pendingRequests = friends.filter { !it.isAccepted }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "متابعة الأقارب وصالح الإخوان",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
            Text(
                "أرسل طلب متابعة لتشجيعهم وتبادل الالتزام في الطاعات ومعدلات الأوراد المكتملة.",
                style = MaterialTheme.typography.bodySmall,
                color = DensitySageSub
            )
        }

        // Send friend request input box
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("إضافة طلب متابعة جديد صريح", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { viewModel.addFriendEmailInput.value = it },
                            placeholder = { Text("مثال: user@rafeeq.com", fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        Button(
                            onClick = {
                                viewModel.sendFriendRequest(emailInput)
                                Toast.makeText(context, "تم إرسال طلب المتابعة", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إرسال")
                        }
                    }
                }
            }
        }

        // Pending Requests Inbox segment
        if (pendingRequests.isNotEmpty()) {
            item {
                Text(
                    "طلبات معلقة بانتظار الموافقة (${pendingRequests.size})",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DensityAccentGold
                )
            }

            items(pendingRequests) { item ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, DensityBg)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(item.name, fontWeight = FontWeight.Bold, color = DensityPrimary, fontSize = 13.sp)
                            Text(if (item.isIncoming) "طلب وارد يريد متابعتك" else "طلب معلق منك إليه", fontSize = 10.sp, color = DensitySageSub)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (item.isIncoming) {
                                Button(
                                    onClick = { viewModel.acceptFriend(item) },
                                    colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    Text("قبول المتابعة", fontSize = 10.sp)
                                }
                            }
                            OutlinedButton(
                                onClick = { viewModel.declineOrDeleteFriend(item.id) },
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.4f)),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text("رفض / إلغاء", fontSize = 10.sp, color = Color.Red)
                            }
                        }
                    }
                }
            }
        }

        // Accepted Friends / Followers Section
        item {
            Text(
                "أصدقاء أتابعهم (${acceptedFriends.size})",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
        }

        if (acceptedFriends.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("قائمة أصدقائك فارغة حالياً.", color = DensitySageSub, fontSize = 12.sp)
                }
            }
        } else {
            items(acceptedFriends) { friend ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(DensityBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        when (friend.avatarType) {
                                            1 -> "🧔"
                                            2 -> "👳"
                                            3 -> "🧕"
                                            4 -> "👑"
                                            else -> "👤"
                                        },
                                        fontSize = 18.sp
                                    )
                                }
                                Column {
                                    Text(friend.name, fontWeight = FontWeight.Bold, color = DensityPrimary, fontSize = 13.sp)
                                    Text("أخر نشاط: ${friend.lastActivity}", fontSize = 9.sp, color = DensitySageSub)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when (friend.todayStatus) {
                                                "مكتمل" -> Color(0xFFE8F5E9)
                                                "جزئي" -> Color(0xFFFFF3E0)
                                                else -> Color(0xFFECEFF1)
                                            }
                                        )
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = friend.todayStatus,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (friend.todayStatus) {
                                            "مكتمل" -> Color(0xFF2E7D32)
                                            "جزئي" -> Color(0xFFEF6C00)
                                            else -> Color(0xFF37474F)
                                        }
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("🔥 ${friend.streak} أيام متتالية", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("الالتزام اليومي المقاس", fontSize = 10.sp, color = DensitySageSub)
                            Text("${(friend.dailyProgress * 100).roundToInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { friend.dailyProgress },
                            color = DensityPrimary,
                            trackColor = DensityBg,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Trigger chips to push them
                        Text("أرسل تحفيز وتصفيق سريع لجماعتك:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DensitySageSub)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            val cheersMap = listOf(
                                "ما شاء الله، همة مباركة! ⭐",
                                "أعاننا الله وإياكم على طاعته وشكره 🤲",
                                "الله يقبل منك ويقويك على الطاعات 🤍"
                            )
                            cheersMap.forEach { text ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DensityBg)
                                        .border(1.dp, DensitySageSub.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                        .clickable {
                                            viewModel.sendCheerMessage(friend.name, text)
                                            Toast.makeText(context, "تم إرسال التحفيز", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(vertical = 4.dp, horizontal = 10.dp)
                                ) {
                                    Text(text = text, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// --- 8. SCREEN: GROUPS AND CHALLENGES ---
@Composable
fun GroupsAndChallengesScreen(viewModel: MainViewModel, profile: UserProfile) {
    val groups by viewModel.allGroupsFlow.collectAsState(initial = emptyList())
    val nameInput by viewModel.newGroupNameInput.collectAsState()
    val descInput by viewModel.newGroupDescInput.collectAsState()
    val joinCodeInput by viewModel.joinGroupCodeInput.collectAsState()

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "مجموعات التنافس والتحديات الجماعية",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
            Text(
                "أنشئ مجموعة عائلية أو انضم مع زملائك لمتابعة الأوراد وحساب متوسط الأداء والالتزام الأسبوعي.",
                style = MaterialTheme.typography.bodySmall,
                color = DensitySageSub,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("انضمام لمجموعات طاعة برابط أو كود دعوة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = joinCodeInput,
                            onValueChange = { viewModel.joinGroupCodeInput.value = it },
                            placeholder = { Text("مثال: MOSQ88", fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        Button(
                            onClick = {
                                viewModel.joinGroup(joinCodeInput)
                                Toast.makeText(context, "تم الانضمام للمجموعة التنافسية", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("انضمام")
                        }
                    }
                }
            }
        }

        item {
            Text(
                "مجموعاتي النشطة (${groups.size})",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
        }

        if (groups.isEmpty()) {
            item {
                Text(
                    "لا تنتمي لأي مجموعة حالياً. تفضل بإنشاء مجموعتك الأولى أدناه.",
                    color = DensitySageSub,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            items(groups) { gp ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(gp.name, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = DensityPrimary)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DensityBg)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("كود: ${gp.inviteCode}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(gp.description, fontSize = 10.sp, color = DensitySageSub)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("الأعضاء", fontSize = 9.sp, color = DensitySageSub)
                                Text("${gp.membersCount} أفراد", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("متوسط الالتزام", fontSize = 9.sp, color = DensitySageSub)
                                Text("${(gp.avgCommitment * 100).roundToInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityAccentGold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DensityProgressCardBg)
                                .padding(10.dp)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("🏆", fontSize = 16.sp)
                                Column {
                                    Text("التحدي الجماعي الأسبوعي المعتمد:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DensitySageSub)
                                    Text(gp.activeChallenge, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                border = BorderStroke(1.dp, DensityBg)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("إنشاء مجموعة جديدة (عائلة / أصدقاء)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = DensityPrimary)

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { viewModel.newGroupNameInput.value = it },
                        label = { Text("اسم المجموعة التنافسي") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { viewModel.newGroupDescInput.value = it },
                        label = { Text("أغراض وتحديات المجموعة") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            viewModel.createGroup(nameInput, descInput)
                            Toast.makeText(context, "تمت إضافة مجموعتك، الكود جاهز للمشاركة", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إنشاء المجموعة وطباعة الكود")
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// --- 9. SCREEN: ANALYTICS REPORTS ---
@Composable
fun ReportsAndStatsScreen(viewModel: MainViewModel, profile: UserProfile) {
    val completions by viewModel.currentCompletions.collectAsState()
    val achievements by viewModel.allAchievementsFlow.collectAsState(initial = emptyList())

    val totalCompletedTasks = completions.count { it.isDone || it.completedCount > 0 }
    val unlockedCount = achievements.count { it.isUnlocked }

    var statsTab by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "سجلات الطاعات وثمرات المواظبة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
        }

        item {
            TabRow(
                selectedTabIndex = statsTab,
                containerColor = DensityBg,
                contentColor = DensityPrimary
            ) {
                Tab(selected = statsTab == 0, onClick = { statsTab = 0 }) {
                    Text("المتابعة والتقارير", fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp), fontSize = 12.sp)
                }
                Tab(selected = statsTab == 1, onClick = { statsTab = 1 }) {
                    Text("أوسمة الإنجاز ($unlockedCount)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp), fontSize = 12.sp)
                }
            }
        }

        if (statsTab == 0) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = DensityCardBg)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("السلسلة المتواصلة 🔥", fontSize = 11.sp, color = DensitySageSub)
                            Text("${profile.consecutiveDays} أيام", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black), color = DensityPrimary)
                            Text("محافظة دون تفريط", fontSize = 9.sp, color = DensitySageSub)
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = DensityCardBg)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("إجمالي الطاعات 🏆", fontSize = 11.sp, color = DensitySageSub)
                            Text("$totalCompletedTasks عمل", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black), color = DensityPrimary)
                            Text("مسجلة وموقوتة", fontSize = 9.sp, color = DensitySageSub)
                        }
                    }
                }
            }

            // High density static progress visual comparison (Mock 7 Days Progress Chart)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "معدل الاستدامة والالتزام بآخر 7 أيام",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = DensityPrimary
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            val values7Days = listOf(
                                "الأحد" to 0.4f,
                                "الاثنين" to 0.75f,
                                "الثلاثاء" to 0.6f,
                                "الأربعاء" to 0.88f,
                                "الخميس" to 0.5f,
                                "الجمعة" to 0.95f,
                                "السبت" to 0.7f
                            )

                            values7Days.forEach { (day, fraction) ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.width(36.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(10.dp)
                                            .height((80 * fraction).dp)
                                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomEnd = 4.dp, bottomStart = 4.dp))
                                            .background(
                                                if (fraction > 0.8f) DensityPrimary else DensitySageSub
                                            )
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(day, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = DensitySageSub)
                                }
                            }
                        }
                    }
                }
            }

            // Conservability stats info
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityProgressCardBg)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("⭐", fontSize = 24.sp)
                        Column {
                            Text("أكثر العبادات محافظة عليها وموطنة بالقلب:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DensitySageSub)
                            Text("صلاة الفجر في جماعة والورد اليومي المرتل", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = DensityPrimary)
                        }
                    }
                }
            }

        } else {
            // Achievements visual listing
            if (achievements.isEmpty()) {
                item {
                    Text("لا توجد أوسمة معززة حالياً.", color = DensitySageSub, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            } else {
                items(achievements) { ach ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.1f)),
                        colors = CardDefaults.cardColors(
                            containerColor = if (ach.isUnlocked) DensityCardBg else DensityCardBg.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (ach.isUnlocked) DensityProgressCardBg else DensityBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (ach.badgeIcon) {
                                        "ic_star" -> "⭐"
                                        "ic_fire" -> "🔥"
                                        "ic_crown" -> "👑"
                                        "ic_book" -> "📖"
                                        "ic_moon" -> "🌙"
                                        else -> "❤️"
                                    },
                                    fontSize = 20.sp
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    ach.title,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (ach.isUnlocked) DensityPrimary else DensitySageSub
                                )
                                Text(
                                    ach.description,
                                    fontSize = 10.sp,
                                    color = DensitySageSub
                                )
                                if (ach.isUnlocked) {
                                    Text(
                                        "تم الفتح بتاريخ: ${ach.unlockDate}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DensityAccentGold,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (ach.isUnlocked) DensityPrimary else DensityBg)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (ach.isUnlocked) "مكتسب" else "مقفل ومبهم",
                                    color = if (ach.isUnlocked) Color.White else DensitySageSub,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// --- 10. SCREEN: PROFILE & SYSTEM SETTINGS ---
@Composable
fun SettingsScreen(viewModel: MainViewModel, profile: UserProfile) {
    var istighfarTargetInput by remember { mutableStateOf(profile.targetIstighfar.toString()) }
    var tasbihTargetInput by remember { mutableStateOf(profile.targetTasbih.toString()) }
    var duaTargetInput by remember { mutableStateOf(profile.targetDua.toString()) }

    var nicknameInput by remember { mutableStateOf(profile.name) }

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "ملف العابد وإعدادات الطاعات",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
        }

        // Account / Info Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("هوّيتك ومزامنة الأجهزة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)

                    OutlinedTextField(
                        value = nicknameInput,
                        onValueChange = { nicknameInput = it },
                        label = { Text("الاسم الكريم") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = profile.email,
                        onValueChange = {},
                        label = { Text("حساب البريد المقترن") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = false,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveUserProfile(profile.copy(name = nicknameInput))
                                Toast.makeText(context, "تم حفظ الاسم بنجاح", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("حفظ التغييرات")
                        }

                        Button(
                            onClick = { viewModel.logout() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("تسجيل الخروج الآمن")
                        }
                    }
                }
            }
        }

        // Set Targets Value
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("تعديل الأهداف اليومية للمسبحة والاستغفار", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)

                    OutlinedTextField(
                        value = istighfarTargetInput,
                        onValueChange = { istighfarTargetInput = it },
                        label = { Text("هدف الاستغفار اليومي") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = tasbihTargetInput,
                        onValueChange = { tasbihTargetInput = it },
                        label = { Text("هدف التسبيح والتحميد اليومي") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = duaTargetInput,
                        onValueChange = { duaTargetInput = it },
                        label = { Text("هدف الصلاة على رسول الله ﷺ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            val ist = istighfarTargetInput.toIntOrNull() ?: 100
                            val tas = tasbihTargetInput.toIntOrNull() ?: 100
                            val dua = duaTargetInput.toIntOrNull() ?: 100
                            viewModel.updateTargetValues(ist, tas, dua)
                            Toast.makeText(context, "تم حفظ أهداف العداد بنجاح!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تعديل وحفظ الأهداف المباركة")
                    }
                }
            }
        }

        // Application Controls and Sync Options
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تفضيلات التنبيهات والخصوصية", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("الوضع المظلم (Dark Mode)", fontSize = 12.sp, color = DensityPrimary)
                        Switch(
                            checked = profile.isDarkMode,
                            onCheckedChange = { viewModel.toggleDarkMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = DensityPrimary)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("تفعيل التنبيهات اليومية والأذكار", fontSize = 12.sp, color = DensityPrimary)
                        Switch(
                            checked = profile.isNotificationsEnabled,
                            onCheckedChange = { viewModel.toggleNotifications(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = DensityPrimary)
                        )
                    }

                    Divider(color = DensityBg, modifier = Modifier.padding(vertical = 4.dp))

                    Text("مستوى الخصوصية الذي يراه الآخرون عند تتبعك:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DensitySageSub)

                    val privacyOptions = listOf(
                        "ALL_DETAILS" to "جميع التفاصيل",
                        "PERCENTAGE_ONLY" to "نسبة الإنجاز دون أرقام",
                        "TASKS_ONLY" to "العبادات المكتملة مبهماً",
                        "NONE" to "إخفاء بالكامل"
                    )

                    privacyOptions.forEach { (level, title) ->
                        val isSel = profile.privacyLevel == level
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.updatePrivacyLevel(level) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSel,
                                onClick = { viewModel.updatePrivacyLevel(level) },
                                colors = RadioButtonDefaults.colors(selectedColor = DensityPrimary)
                            )
                            Text(title, fontSize = 11.sp, color = DensityPrimary)
                        }
                    }
                }
            }
        }

        // Action controls
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("عمليات المزامنة والتوطين الاحتياطي", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DensityPrimary)

                    Text(
                        text = "الحالة الأساسية: ${profile.syncStatus}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = DensitySageSub
                    )

                    Button(
                        onClick = { viewModel.triggerDataSync() },
                        colors = ButtonDefaults.buttonColors(containerColor = DensitySageSub),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مزامنة البيانات السحابية (Supabase)")
                    }

                    OutlinedButton(
                        onClick = {
                            Toast.makeText(context, "تم تصدير نسخة JSON لملفاتك لبطاقة التخزين بنجاح!", Toast.LENGTH_LONG).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, DensitySageSub),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تصدير الأوراد والبيانات كـ JSON")
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// --- SUBVIEWS FOR LIBRARY ---
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SurahListView(onSelect: (Surah) -> Unit) {
    val surahs = LibraryData.quranSurahs
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DensityPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("📖", fontSize = 28.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("القرآن الكريم كاملاً", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("متاح تلاوة مع الورد المختار لقراءة الأوراد والبركة.", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        items(surahs) { surah ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth(),
                onClick = { onSelect(surah) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(DensityBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(surah.id.toString(), fontSize = 11.sp, fontWeight = FontWeight.Black, color = DensityPrimary)
                        }
                        Column {
                            Text(surah.name, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = DensityPrimary)
                            Text("عدد الآيات: ${surah.versesCount} | ${surah.type}", fontSize = 10.sp, color = DensitySageSub)
                        }
                    }
                    Text("قراءة 📖", color = DensityAccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SurahReaderView(surah: Surah, viewModel: MainViewModel, onBack: () -> Unit) {
    val currentPlayingSurahId by viewModel.currentPlayingSurahId.collectAsState()
    val currentPlayingVerseIndex by viewModel.currentPlayingVerseIndex.collectAsState()
    val audioState by viewModel.audioState.collectAsState()
    val audioErrorMessage by viewModel.audioErrorMessage.collectAsState()
    val isLoadingVerses by viewModel.isLoadingVerses.collectAsState()
    val selectedReciter by viewModel.selectedReciter.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("← قائمة السور", color = DensitySageSub, fontWeight = FontWeight.Bold)
            }
            Text(
                "سُورَةُ " + surah.name,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                color = DensityPrimary
            )
            // Premium play-all/pause button
            IconButton(
                onClick = {
                    if (currentPlayingSurahId == surah.id) {
                        viewModel.togglePlayPause()
                    } else {
                        viewModel.playQuranVerse(surah.id, 0)
                    }
                }
            ) {
                val icon = if (currentPlayingSurahId == surah.id && audioState == AudioPlaybackState.PLAYING) {
                    Icons.Rounded.Pause
                } else {
                    Icons.Rounded.PlayArrow
                }
                Icon(icon, contentDescription = "تشغيل السورة كاملة", tint = DensitySageSub, modifier = Modifier.size(28.dp))
            }
        }

        // QURAN READERS / RECITERS SELECTION ROW
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(DensityPrimary.copy(alpha = 0.05f))
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = "القارئ",
                tint = DensitySageSub,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "القارئ الحالي:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DensityPrimary
            )
            Spacer(modifier = Modifier.width(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(viewModel.recitersList) { reciter ->
                    val isSelected = (reciter.id == selectedReciter.id)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                1.dp,
                                if (isSelected) DensityPrimary else DensitySageSub.copy(alpha = 0.2f),
                                RoundedCornerShape(8.dp)
                            )
                            .background(if (isSelected) DensityPrimary else Color.Transparent)
                            .clickable {
                                viewModel.selectReciter(reciter)
                            }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = reciter.name,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else DensityPrimary
                        )
                    }
                }
            }
        }

        if (audioErrorMessage != null) {
            Text(
                text = audioErrorMessage ?: "",
                color = Color.Red,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            if (isLoadingVerses) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = DensityPrimary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "جاري تحميل آيات السورة الكريمة من الشبكة...",
                            color = DensityPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "سيتم تفعيل خدمة التلاوة والقراءة فور انتهاء التحميل المبارك.",
                            color = DensitySageSub,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    border = BorderStroke(1.dp, DensitySageSub.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxSize()
                ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (surah.id != 1) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(
                                    text = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DensityPrimary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                            }
                        }
                    }

                    itemsIndexed(surah.verses) { index, verse ->
                        val isThisPlaying = (currentPlayingSurahId == surah.id && currentPlayingVerseIndex == index)
                        val highlightBg = if (isThisPlaying) DensityPrimary.copy(alpha = 0.08f) else Color.Transparent

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(highlightBg)
                                .clickable {
                                    viewModel.playQuranVerse(surah.id, index)
                                }
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = verse,
                                fontSize = 17.sp,
                                fontWeight = if (isThisPlaying) FontWeight.Bold else FontWeight.Medium,
                                lineHeight = 28.sp,
                                color = if (isThisPlaying) DensityPrimary else MaterialTheme.colorScheme.onBackground,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Verse number circle indicator
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(if (isThisPlaying) DensityPrimary else DensityBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = (index + 1).toString(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isThisPlaying) Color.White else DensitySageSub
                                    )
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                // Dynamic Verse action or audio waves icon
                                if (isThisPlaying) {
                                    when (audioState) {
                                        AudioPlaybackState.LOADING -> {
                                            CircularProgressIndicator(
                                                color = DensityPrimary,
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp
                                            )
                                        }
                                        AudioPlaybackState.PLAYING -> {
                                            Icon(
                                                imageVector = Icons.Rounded.Pause,
                                                contentDescription = "إيقاف مؤقت للآية",
                                                tint = DensityPrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("جاري التلاوة...", fontSize = 10.sp, color = DensitySageSub, fontWeight = FontWeight.Bold)
                                        }
                                        AudioPlaybackState.PAUSED -> {
                                            Icon(
                                                imageVector = Icons.Rounded.PlayArrow,
                                                contentDescription = "استئناف الآية",
                                                tint = DensityPrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        else -> {
                                            Icon(
                                                imageVector = Icons.Rounded.PlayArrow,
                                                contentDescription = "تشغيل الآية",
                                                tint = DensitySageSub,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "تشغيل الآية",
                                        tint = DensitySageSub.copy(alpha = 0.5f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            HorizontalDivider(
                                color = DensityBg,
                                modifier = Modifier.padding(top = 10.dp),
                                thickness = 1.dp
                            )
                        }
                    }
                }
            }
            }

            // Floating premium recitation controller at the bottom
            if (currentPlayingSurahId == surah.id) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(DensityPrimary)
                        .padding(vertical = 10.dp, horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.VolumeUp, contentDescription = "تلاوة", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Text(
                                    text = "تلاوة بصوت الشيخ العفاسي",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "الآية رقم ${(currentPlayingVerseIndex ?: 0) + 1}",
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (audioState == AudioPlaybackState.LOADING) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                            } else {
                                IconButton(
                                    onClick = { viewModel.togglePlayPause() },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    val icon = if (audioState == AudioPlaybackState.PLAYING) {
                                        Icons.Rounded.Pause
                                    } else {
                                        Icons.Rounded.PlayArrow
                                    }
                                    Icon(icon, contentDescription = "تشغيل/إيقاف مؤقت", tint = Color.White, modifier = Modifier.size(28.dp))
                                }
                            }

                            IconButton(
                                onClick = { viewModel.stopQuranVerse() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = "إيقاف", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AzkarCategorySelector(onSelect: (String) -> Unit) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        val categories = listOf(
            Triple("MORNING", "أذكار الصباح كاملة", "يقال بعد صلاة الفجر ومطلع الشروق للحماية الإلهية البركة."),
            Triple("EVENING", "أذكار المساء المأثورة", "يقال بعد عصر اليوم وقبيل الغروب للحفظ من الهم والهوام."),
            Triple("POST_PRAYER", "الأذكار دبر الصلوات المفروضة", "السنن المعقبة دبر الصلوات الخمس مباشرة لكسب الأجور العظيمة.")
        )

        categories.forEach { (key, label, desc) ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DensitySageSub.copy(alpha = 0.1f), RoundedCornerShape(16.dp)),
                onClick = { onSelect(key) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("📿", fontSize = 32.sp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(label, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = DensityPrimary)
                        Text(desc, fontSize = 10.sp, color = DensitySageSub)
                    }
                    Text("ابدأ الورد", color = DensityAccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AzkarCounterView(
    category: String,
    countsMap: Map<Int, Int>,
    onTap: (Int) -> Unit,
    onBack: () -> Unit
) {
    val items = when (category) {
        "MORNING" -> LibraryData.morningAzkar
        "EVENING" -> LibraryData.eveningAzkar
        else -> LibraryData.postPrayerAzkar
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("← العودة لقائمة الأوراد", color = DensitySageSub, fontWeight = FontWeight.Bold)
            }
            Text(
                "حصن المقرئ اليوم",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(items) { index, item ->
                val rem = countsMap[index] ?: 0
                val isDone = rem == 0

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDone) DensityProgressCardBg else DensityCardBg),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (!isDone) onTap(index) }
                        .border(1.dp, DensitySageSub.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            item.text,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 22.sp, fontWeight = FontWeight.Medium),
                            color = DensityPrimary
                        )
                        if (item.reward.isNotEmpty()) {
                            Text(
                                "الفضل والمصدر: ${item.reward}",
                                fontSize = 10.sp,
                                fontStyle = FontStyle.Normal,
                                color = DensitySageSub,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isDone) "تم الإكمال بنجاح ✓" else "التكرار المطلق المتبقي: $rem",
                                fontSize = 11.sp,
                                color = if (isDone) DensityPrimary else DensitySageSub,
                                fontWeight = FontWeight.Bold
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isDone) DensityBg else DensityPrimary)
                                    .clickable { if (!isDone) onTap(index) }
                                    .padding(vertical = 6.dp, horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isDone) "مكتمل" else "اضغط للتكرار ($rem)",
                                    color = if (isDone) DensityPrimary else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BooksListView(onSelect: (HadithBook) -> Unit) {
    val books = LibraryData.customBooks
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(books) { book ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DensitySageSub.copy(alpha = 0.1f), RoundedCornerShape(16.dp)),
                onClick = { onSelect(book) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("📚", fontSize = 28.sp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(book.title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = DensityPrimary)
                        Text("الكاتب والمصنف: ${book.author}", fontSize = 10.sp, color = DensitySageSub)
                    }
                    Text("تصفح 📖", color = DensityAccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BookChapterView(book: HadithBook, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("← المكتبة المعتمدة", color = DensitySageSub, fontWeight = FontWeight.Bold)
            }
            Text(
                book.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DensityPrimary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(book.chapters) { cap ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DensityCardBg),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, DensityBg)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            cap.title,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = DensityAccentGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        cap.content.forEach { sentence ->
                            Text(
                                sentence,
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 22.sp),
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddCustomTaskDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("صلاة") }

    val categories = listOf("صلاة", "أذكار", "قرآن", "أخرى")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DensityCardBg),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "إضافة عبادة أو عمل مخصص",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = DensityPrimary
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم العبادة (مثال: صلاة الضحى)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Text("اختر التصنيف الرئيسي للعمل:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = DensitySageSub)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEach { cat ->
                        val isSel = category == cat
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSel) DensityPrimary else DensityBg)
                                .clickable { category = cat }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                cat,
                                color = if (isSel) Color.White else DensityPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = {
                            if (title.isNotEmpty()) {
                                viewModel.addCustomTask(title, category)
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DensityPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إضافة وحفظ")
                    }
                }
            }
        }
    }
}
