package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserProfile(
    @PrimaryKey val email: String,
    val name: String,
    val targetIstighfar: Int = 100,
    val targetTasbih: Int = 100,
    val targetDua: Int = 100,
    val isNotificationsEnabled: Boolean = true,
    val isDarkMode: Boolean = false,
    val privacyLevel: String = "ALL_DETAILS", // "ALL_DETAILS", "PERCENTAGE_ONLY", "TASKS_ONLY", "NONE"
    val consecutiveDays: Int = 7,
    val totalTasksCompleted: Int = 45,
    val syncStatus: String = "إتمام المزامنة بنجاح"
)

@Entity(tableName = "daily_tasks")
data class DailyTask(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String, // "صلاة", "أذكار", "قرآن", "عداد", "أخرى"
    val isSystem: Boolean,
    val defaultTarget: Int = 1
)

@Entity(tableName = "task_completion")
data class TaskCompletion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskId: Int,
    val date: String, // "YYYY-MM-DD"
    val completedCount: Int,
    val isDone: Boolean = false
)

@Entity(tableName = "friendships")
data class Friendship(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val email: String,
    val name: String,
    val avatarType: Int, // 1 to 5
    val dailyProgress: Float, // 0.0 to 1.0
    val streak: Int,
    val todayStatus: String, // "لم يبدأ", "جزئي", "مكتمل"
    val lastActivity: String,
    val isAccepted: Boolean, // false = friend request pending
    val isIncoming: Boolean = false // true if they sent request to us
)

@Entity(tableName = "groups")
data class GroupEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val inviteCode: String,
    val membersCount: Int,
    val avgCommitment: Float, // 0.0 - 1.0
    val activeChallenge: String = "تحدي ختم سورة الكهف في الويكيند"
)

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val badgeIcon: String, // Icon specifier
    val isUnlocked: Boolean,
    val unlockDate: String = ""
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = "INFO" // "CHEER", "CONGRATS", "REMINDER"
)
