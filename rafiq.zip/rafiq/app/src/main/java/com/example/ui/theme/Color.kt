package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val PrimaryGreen = Color(0xFF0F4C3A) // Deep Mosque Emerald Green
val SecondarySage = Color(0xFF2A7E62) // Calm Sage Green
val WarmGold = Color(0xFFC59B27) // Premium Sand/Golden Accent
val BackgroundCream = Color(0xFFFBFBFA) // Soft Eye-Safe Off-White Canvas
val SurfaceWhite = Color(0xFFFFFFFF) // White Cards
val TextCharcoal = Color(0xFF232B28) // Deep Charcoal

// Dark Colors
val DarkPrimaryGreen = Color(0xFF388E6D)
val DarkSecondarySage = Color(0xFF4DB6AC)
val DarkBackgroundBlack = Color(0xFF111E1A) // Safe Dark Jade Black
val DarkSurfaceCard = Color(0xFF172822) // Lighter Jade Jade
val DarkTextWhite = Color(0xFFE8F5E9)

