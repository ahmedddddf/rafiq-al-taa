package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimaryGreen,
    secondary = DarkSecondarySage,
    tertiary = WarmGold,
    background = DarkBackgroundBlack,
    surface = DarkSurfaceCard,
    onPrimary = DarkBackgroundBlack,
    onSecondary = DarkBackgroundBlack,
    onBackground = DarkTextWhite,
    onSurface = DarkTextWhite
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryGreen,
    secondary = SecondarySage,
    tertiary = WarmGold,
    background = BackgroundCream,
    surface = SurfaceWhite,
    onPrimary = SurfaceWhite,
    onSecondary = SurfaceWhite,
    onBackground = TextCharcoal,
    onSurface = TextCharcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to preserve the customized green/white theme identity
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
