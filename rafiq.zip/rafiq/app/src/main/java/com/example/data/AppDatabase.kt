package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserProfile::class,
        DailyTask::class,
        TaskCompletion::class,
        Friendship::class,
        GroupEntity::class,
        Achievement::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rafeeq_al_taah_db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.appDao())
                }
            }
        }

        suspend fun populateDatabase(dao: AppDao) {
            // 1. Initial User Profile
            dao.insertUserProfile(
                UserProfile(
                    email = "ahmedaljubari3@gmail.com",
                    name = "أحمد الجباري",
                    targetIstighfar = 100,
                    targetTasbih = 100,
                    targetDua = 100,
                    isNotificationsEnabled = true,
                    isDarkMode = false,
                    privacyLevel = "ALL_DETAILS",
                    consecutiveDays = 9,
                    totalTasksCompleted = 104
                )
            )

            // 2. Default System Devotional Tasks
            val defaultTasks = listOf(
                DailyTask(id = 1, name = "الصلوات الخمس المفروضة جماعة", category = "صلاة", isSystem = true, defaultTarget = 1),
                DailyTask(id = 2, name = "صلاة سنّة الوتر والشفع", category = "صلاة", isSystem = true, defaultTarget = 1),
                DailyTask(id = 3, name = "قراءة أذكار الصباح", category = "أذكار", isSystem = true, defaultTarget = 1),
                DailyTask(id = 4, name = "قراءة أذكار المساء", category = "أذكار", isSystem = true, defaultTarget = 1),
                DailyTask(id = 5, name = "ورد قراءة جزء أو صفحة من القرآن", category = "قرآن", isSystem = true, defaultTarget = 1),
                DailyTask(id = 6, name = "مراجعة وحفظ الآيات المقررة", category = "قرآن", isSystem = true, defaultTarget = 1),
                DailyTask(id = 7, name = "بذل صدقة اليوم (ولو بشق تمرة)", category = "أخرى", isSystem = true, defaultTarget = 1),
                DailyTask(id = 8, name = "قيام الليل والتهجد", category = "صلاة", isSystem = true, defaultTarget = 1),
                DailyTask(id = 9, name = "صيام النافلة (الاثنين والخميس)", category = "أخرى", isSystem = true, defaultTarget = 1),
                DailyTask(id = 10, name = "الاستغفار اليومي بالعداد", category = "عداد", isSystem = true, defaultTarget = 100),
                DailyTask(id = 11, name = "التسبيح والتحميد والتكبير", category = "عداد", isSystem = true, defaultTarget = 100),
                DailyTask(id = 12, name = "الصلاة والسلام على النبي ﷺ", category = "عداد", isSystem = true, defaultTarget = 100)
            )
            for (task in defaultTasks) {
                dao.insertTask(task)
            }

            // 3. Populate Some Completed Tasks for History (for dynamic reports)
            // Just some sample records for yesterday and today
            val today = "2026-06-08"
            val yesterday = "2026-06-07"
            val completions = listOf(
                TaskCompletion(taskId = 1, date = yesterday, completedCount = 1, isDone = true),
                TaskCompletion(taskId = 3, date = yesterday, completedCount = 1, isDone = true),
                TaskCompletion(taskId = 10, date = yesterday, completedCount = 120, isDone = true),
                TaskCompletion(taskId = 11, date = yesterday, completedCount = 100, isDone = true),
                TaskCompletion(taskId = 12, date = yesterday, completedCount = 200, isDone = true),
                
                TaskCompletion(taskId = 1, date = today, completedCount = 1, isDone = true),
                TaskCompletion(taskId = 3, date = today, completedCount = 1, isDone = true),
                TaskCompletion(taskId = 10, date = today, completedCount = 45, isDone = false) // partial completion
            )
            for (comp in completions) {
                dao.insertCompletion(comp)
            }

            // 4. Initial friendships / followers for the simulator
            val friends = listOf(
                Friendship(name = "معاذ الغامدي", email = "moath@rafeeq.com", avatarType = 1, dailyProgress = 0.92f, streak = 15, todayStatus = "مكتمل", lastActivity = "منذ ٥ دقائق - أتم أذكار المساء والوتر", isAccepted = true),
                Friendship(name = "عبدالرحمن الحربي", email = "abdu@rafeeq.com", avatarType = 2, dailyProgress = 0.70f, streak = 8, todayStatus = "جزئي", lastActivity = "منذ ساعة - أكمل 500 تسبيحة واستغفار", isAccepted = true),
                Friendship(name = "صالح بن علي البارقي", email = "saleh@rafeeq.com", avatarType = 3, dailyProgress = 0.00f, streak = 4, todayStatus = "لم يبدأ", lastActivity = "أمس - أكمل قراءة القرآن والصدقة", isAccepted = true),
                Friendship(name = "ياسر الشمري", email = "yasser@rafeeq.com", avatarType = 4, dailyProgress = 0.00f, streak = 0, todayStatus = "لم يبدأ", lastActivity = "بانتظار الموافقة", isAccepted = false, isIncoming = false), // Pending sent
                Friendship(name = "فيصل العتيبي", email = "faisal@rafeeq.com", avatarType = 5, dailyProgress = 0.85f, streak = 12, todayStatus = "جزئي", lastActivity = "طلب متابعة جديد", isAccepted = false, isIncoming = true) // Pending incoming
            )
            for (f in friends) {
                dao.insertFriendship(f)
            }

            // 5. Initial groups
            val groups = listOf(
                GroupEntity(name = "عائلة آل جباري المباركة", description = "مساحة تجمع العائلة للتآزر ومتابعة الصلوات والقرآن يومياً للتنافس المفيد.", inviteCode = "JUBARI26", membersCount = 6, avgCommitment = 0.88f),
                GroupEntity(name = "شباب مسجد الصف الكرام", description = "مجموعتنا الخاصة بالتواصي بالحق والتنافس في قراءة الأذكار وسنن الاستغفار والتبكير للجماعة.", inviteCode = "MOSQ88", membersCount = 12, avgCommitment = 0.94f)
            )
            for (g in groups) {
                dao.insertGroup(g)
            }

            // 6. Initial achievements
            val initialAchievements = listOf(
                Achievement("first_step", "الخطوة الأولى", "تفعيل حسابك في تطبيق رفيق الطاعة وتسجيل أول عبادة بنجاح", "ic_star", true, "1447/12/24 هـ"),
                Achievement("streak_7", "مثابر الأسبوع", "تأدية الصلوات والورد اليومي لمدة 7 أيام متتالية دون انقطاع", "ic_fire", true, "1447/12/28 هـ"),
                Achievement("streak_30", "نجم الثلاثين", "إتمام الأوراد اليومية لمدة 30 يوماً متتالياً وبث الهمّة للأصدقاء", "ic_crown", false),
                Achievement("quran_lover", "صاحب القرآن", "قراءة الورد اليومي دون تفريظ لـ 15 يوماً متتالياً", "ic_book", false),
                Achievement("super_dhikr", "المليون المستغفر", "محافظة تامة على أذكار اليوم وتجاوز 1000 تسبيحة في عداد العبادة", "ic_moon", true, "1447/12/29 هـ"),
                Achievement("charity_hero", "الباذل المنفق", "تسجيل الصدقة والإنفاق وبذل المعروف لـ 5 أيام متفرقة", "ic_heart", false)
            )
            for (ach in initialAchievements) {
                dao.insertAchievement(ach)
            }

            // 7. Initial notifications
            val notifications = listOf(
                NotificationEntity(text = "تم قبول طلب المتابعة الخاص بك من معاذ الغامدي. يمكنك الآن تبادل التشجيع معه!", type = "CHEER"),
                NotificationEntity(text = "مبارك! لقد أنجزت سلسلة التزام متواصلة تبلغ 9 أيام، استمر بارك الله بك وفيك!", type = "CONGRATS"),
                NotificationEntity(text = "أرسل لك عبدالرحمن الحربي تحية تشجيعية: 'الله يتقبل منك ويقويك على الطاعة والخير 🤍'", type = "CHEER")
            )
            for (not in notifications) {
                dao.insertNotification(not)
            }
        }
    }
}
