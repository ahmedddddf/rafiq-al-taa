package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- USER PROFILE ---
    @Query("SELECT * FROM users LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserProfile(profile: UserProfile)

    // --- DAILY TASKS ---
    @Query("SELECT * FROM daily_tasks ORDER BY id ASC")
    fun getAllTasks(): Flow<List<DailyTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: DailyTask): Long

    @Query("DELETE FROM daily_tasks WHERE id = :taskId")
    suspend fun deleteTaskById(taskId: Int)

    // --- TASK COMPLETION ---
    @Query("SELECT * FROM task_completion WHERE date = :date")
    fun getCompletionsByDate(date: String): Flow<List<TaskCompletion>>

    @Query("SELECT * FROM task_completion")
    fun getAllCompletions(): Flow<List<TaskCompletion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompletion(completion: TaskCompletion)

    @Query("DELETE FROM task_completion WHERE taskId = :taskId")
    suspend fun deleteCompletionsByTaskId(taskId: Int)

    // --- FRIENDSHIPS / FOLLOWING ---
    @Query("SELECT * FROM friendships ORDER BY id DESC")
    fun getAllFriends(): Flow<List<Friendship>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriendship(friend: Friendship)

    @Update
    suspend fun updateFriendship(friend: Friendship)

    @Query("DELETE FROM friendships WHERE id = :id")
    suspend fun deleteFriendship(id: Int)

    // --- GROUPS ---
    @Query("SELECT * FROM groups ORDER BY id DESC")
    fun getAllGroups(): Flow<List<GroupEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGroup(group: GroupEntity)

    @Query("DELETE FROM groups WHERE id = :id")
    suspend fun deleteGroup(id: Int)

    // --- ACHIEVEMENTS ---
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<Achievement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievement(achievement: Achievement)

    // --- NOTIFICATIONS ---
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()
}
