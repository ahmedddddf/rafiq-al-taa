package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

sealed class Screen {
    object Auth : Screen()
    object Home : Screen()
    object Counters : Screen()
    object Library : Screen()
    object Social : Screen()
    object Groups : Screen()
    object Reports : Screen()
    object Settings : Screen()
}

enum class AudioPlaybackState {
    IDLE, LOADING, PLAYING, PAUSED, ERROR
}

data class QuranReciter(val id: String, val name: String, val folder: String)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = AppRepository(db.appDao())

    // --- NAVIGATION ---
    val currentScreen = MutableStateFlow<Screen>(Screen.Home)

    // --- AUTHENTICATION STATE ---
    val loggedInUser = MutableStateFlow<UserProfile?>(null)
    val loginError = MutableStateFlow<String?>(null)
    val isAuthLoading = MutableStateFlow(false)

    // --- GENERAL STATES ---
    val selectedDate = MutableStateFlow("") // "YYYY-MM-DD"
    val showNotificationBadge = MutableStateFlow(true)

    // --- SELECTION STATES FOR LIBRARY ---
    val activeSurah = MutableStateFlow<Surah?>(null)
    val isLoadingVerses = MutableStateFlow(false)
    val activeAzkarCategory = MutableStateFlow<String?>(null) // "MORNING", "EVENING", "POST_PRAYER"
    val activeZikrTapCounts = MutableStateFlow<Map<Int, Int>>(emptyMap())

    val recitersList = listOf(
        QuranReciter("alafasy", "مشاري راشد العفاسي", "Alafasy_128kbps"),
        QuranReciter("abdulbasit", "عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_64kbps"),
        QuranReciter("minshawy", "محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"),
        QuranReciter("husary", "محمود خليل الحصري", "Husary_128kbps"),
        QuranReciter("ghamadi", "سعد الغامدي", "Ghamadi_40kbps"),
        QuranReciter("muaiqly", "ماهر المعيقلي", "Maher_AlMuaiqly_64kbps"),
        QuranReciter("sudais", "عبد الرحمن السديس", "Abdurrahmaan_As-Sudais_128kbps"),
        QuranReciter("shatri", "أبو بكر الشاطري", "Shatri_128kbps")
    )
    val selectedReciter = MutableStateFlow(recitersList[0])

    fun selectReciter(reciter: QuranReciter) {
        selectedReciter.value = reciter
        val playingSurahId = currentPlayingSurahId.value
        val playingVerseIndex = currentPlayingVerseIndex.value
        if (playingSurahId != null && playingVerseIndex != null && audioState.value == AudioPlaybackState.PLAYING) {
            playQuranVerse(playingSurahId, playingVerseIndex)
        }
    }

    val activeBook = MutableStateFlow<HadithBook?>(null)

    // --- AUDIO RECITATION STATES ---
    private var mediaPlayer: android.media.MediaPlayer? = null
    val currentPlayingSurahId = MutableStateFlow<Int?>(null)
    val currentPlayingVerseIndex = MutableStateFlow<Int?>(null)
    val audioState = MutableStateFlow<AudioPlaybackState>(AudioPlaybackState.IDLE)
    val audioErrorMessage = MutableStateFlow<String?>(null)

    // --- COMPANION / SOCIAL INPUT CODES ---
    val addFriendEmailInput = MutableStateFlow("")
    val newGroupNameInput = MutableStateFlow("")
    val newGroupDescInput = MutableStateFlow("")
    val joinGroupCodeInput = MutableStateFlow("")

    // --- MOTIVATIONAL QUOTE STATE ---
    val motivationalQuote = MutableStateFlow("محرابك بانتظارك! قال تعالى: {وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ}... ابدأ يومك بهمة عالية.")
    val isQuoteLoading = MutableStateFlow(false)

    // Observables directly from Repository
    val userProfileFlow: Flow<UserProfile?> = repository.userProfile
    val allTasksFlow: Flow<List<DailyTask>> = repository.allTasks
    val allFriendsFlow: Flow<List<Friendship>> = repository.allFriends
    val allGroupsFlow: Flow<List<GroupEntity>> = repository.allGroups
    val allAchievementsFlow: Flow<List<Achievement>> = repository.allAchievements
    val allNotificationsFlow: Flow<List<NotificationEntity>> = repository.allNotifications
    val allCompletions: Flow<List<TaskCompletion>> = repository.allCompletions

    // Completions map for the selected date
    private val _currentCompletions = MutableStateFlow<List<TaskCompletion>>(emptyList())
    val currentCompletions: StateFlow<List<TaskCompletion>> = _currentCompletions

    init {
        // Set today's date
        val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        selectedDate.value = df.format(Date())

        // Watch selectedDate and fetch completions accordingly
        viewModelScope.launch {
            selectedDate.collectLatest { date ->
                if (date.isNotEmpty()) {
                    repository.getCompletionsByDate(date).collect { list ->
                        _currentCompletions.value = list
                    }
                }
            }
        }

        // Set logged in user state from db
        viewModelScope.launch {
            repository.userProfile.collect { profile ->
                if (profile != null && loggedInUser.value == null) {
                    loggedInUser.value = profile
                }
            }
        }

        // Generate customized Islamic motivation quote
        generateMotivationalQuote()
    }

    // --- AUTH ACTIONS ---
    fun login(email: String, name: String) {
        viewModelScope.launch {
            isAuthLoading.value = true
            delay(1000) // simulation
            if (email.contains("@")) {
                val profile = UserProfile(
                    email = email,
                    name = name.ifEmpty { "أحمد الجباري" },
                    consecutiveDays = 9,
                    totalTasksCompleted = 104
                )
                repository.insertUserProfile(profile)
                loggedInUser.value = profile
                currentScreen.value = Screen.Home
                loginError.value = null
            } else {
                loginError.value = "الرجاء إدخال بريد إلكتروني صحيح وصالح."
            }
            isAuthLoading.value = false
        }
    }

    fun logout() {
        loggedInUser.value = null
        currentScreen.value = Screen.Auth
    }

    fun signUp(email: String, name: String) {
        login(email, name)
    }

    fun recoverPassword(email: String) {
        viewModelScope.launch {
            isAuthLoading.value = true
            delay(1000)
            loginError.value = "تم إرسال رابط استعادة كلمة المرور بنجاح إلى الرقم والبريد الإلكتروني المذكور."
            isAuthLoading.value = false
        }
    }

    // --- DATE SWITCHING ---
    fun setDate(date: String) {
        selectedDate.value = date
        generateMotivationalQuote()
    }

    // --- MOTIVATION ENGINE (GEMINI API WITH LOCAL FALLBACK) ---
    fun generateMotivationalQuote() {
        viewModelScope.launch {
            isQuoteLoading.value = true
            val prompt = "أنت مساعد إسلامي بليغ في تطبيق 'رفيق الطاعة'. اكتب مقولة تحفيزية وتوجيهية قصيرة جداً (سطرين كحد أقصى) للمستخدم تدعوه فيها للمحافظة على صلواته وقراءة القرآن والأذكار والاستغفار اليوم لتقريب العبد لربه، مستشهداً بآية أو حديث شريف بشكل محبب ومبشر بالنور والرحمة والبركة باللغة العربية الفصحى."
            val res = fetchGeminiQuote(prompt)
            if (res != null && !res.contains("Error")) {
                motivationalQuote.value = res.trim()
            } else {
                // Return offline fallback quote based on weekdays
                motivationalQuote.value = getLocalFallbackQuote()
            }
            isQuoteLoading.value = false
        }
    }

    private suspend fun fetchGeminiQuote(prompt: String): String? {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isEmpty() || key == "MY_GEMINI_API_KEY") return null

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$key"
            val client = OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            val jsonBody = JSONObject().apply {
                put("contents", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val responseStr = response.body?.string() ?: ""
                val obj = JSONObject(responseStr)
                val candidates = obj.getJSONArray("candidates")
                val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                parts.getJSONObject(0).getString("text")
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun getLocalFallbackQuote(): String {
        val fallbackQuotes = listOf(
            "قال رسول الله ﷺ: (أحب الأعمال إلى الله أدومها وإن قل)... واصل وريدك اليومي ليبقى قلبك موصولاً بربك.",
            "محرابك بانتظارك! قال تعالى: {وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ}... إن الصلاة كانت على المؤمنين كتاباً موقوتاً.",
            "يوم جديد يحمل رضا الرحمن وغفران الذنوب! قال تعالى: {وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا}.",
            "استنِر بنور الرحمن! قراءة صفحة واحدة من القرآن تضيف مئات الحسنات في صحيفتك، طهّر سمعك وقلبك.",
            "الاستغفار يفتح الأقفال ويجلب الأرزاق والمطر والبركة! قال تعالى: {فَقُلْتُ اسْتَغْفِرُوا رَبَّكُمْ إِنَّهُ كَانَ غَفَّارًا}.",
            "صلاة الوتر هي أنس في ظلمة الليل، ضياء لطريقك المزدحم، فلا تحرم نفسك ركعة تقربك من عرش الرحمن.",
            "اللهم صلّ وسلم على نبينا محمد... من صلى عليه صلاة واحدة صلى الله بها عليه عشراً، املأ صحيفتك بالصلاة على الحبيب."
        )
        return fallbackQuotes[Random().nextInt(fallbackQuotes.size)]
    }

    // --- WORSHIP TRACKING ACTIONS ---
    fun toggleWorshipCompletion(task: DailyTask, isDone: Boolean, count: Int = 1) {
        viewModelScope.launch(Dispatchers.IO) {
            val date = selectedDate.value
            val existing = _currentCompletions.value.find { it.taskId == task.id }
            if (existing != null) {
                if (isDone || count > 0) {
                    val updated = existing.copy(
                        completedCount = count,
                        isDone = isDone
                    )
                    repository.insertCompletion(updated)
                } else {
                    // remove completion
                    repository.insertCompletion(existing.copy(completedCount = 0, isDone = false))
                }
            } else {
                val newCompletion = TaskCompletion(
                    taskId = task.id,
                    date = date,
                    completedCount = count,
                    isDone = isDone
                )
                repository.insertCompletion(newCompletion)
            }
        }
    }

    // --- COUNTER ACTIONS ---
    fun incrementCounter(task: DailyTask) {
        val existing = _currentCompletions.value.find { it.taskId == task.id }
        val currentVal = existing?.completedCount ?: 0
        val newVal = currentVal + 1
        val target = getTargetForCounter(task.id)
        val isCompleted = newVal >= target

        toggleWorshipCompletion(task, isCompleted, newVal)
    }

    fun getTargetForCounter(taskId: Int): Int {
        val user = loggedInUser.value ?: return 100
        return when (taskId) {
            10 -> user.targetIstighfar
            11 -> user.targetTasbih
            12 -> user.targetDua
            else -> 100
        }
    }

    // --- CUSTOM TASK CREATION ---
    fun addCustomTask(name: String, category: String) {
        if (name.trim().isEmpty()) return
        viewModelScope.launch {
            repository.insertTask(
                DailyTask(
                    name = name,
                    category = category,
                    isSystem = false,
                    defaultTarget = 1
                )
            )
        }
    }

    fun removeCustomTask(taskId: Int) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
        }
    }

    // --- SETTINGS AND TARGETS EDITING ---
    fun saveUserProfile(profile: UserProfile) {
        viewModelScope.launch {
            repository.insertUserProfile(profile)
            loggedInUser.value = profile
        }
    }

    fun updateTargetValues(istighfar: Int, tasbih: Int, dua: Int) {
        val currentUser = loggedInUser.value ?: return
        saveUserProfile(
            currentUser.copy(
                targetIstighfar = istighfar,
                targetTasbih = tasbih,
                targetDua = dua
            )
        )
    }

    fun toggleDarkMode(enabled: Boolean) {
        val currentUser = loggedInUser.value ?: return
        saveUserProfile(currentUser.copy(isDarkMode = enabled))
    }

    fun toggleNotifications(enabled: Boolean) {
        val currentUser = loggedInUser.value ?: return
        saveUserProfile(currentUser.copy(isNotificationsEnabled = enabled))
    }

    fun updatePrivacyLevel(level: String) {
        val currentUser = loggedInUser.value ?: return
        saveUserProfile(currentUser.copy(privacyLevel = level))
    }

    fun triggerDataSync() {
        viewModelScope.launch {
            val user = loggedInUser.value ?: return@launch
            saveUserProfile(user.copy(syncStatus = "المزامنة قيد المعالجة..."))
            delay(1500)
            saveUserProfile(user.copy(syncStatus = "تمت المزامنة بنجاح وحفظ الإحصائيات والأوراد السحابية."))
        }
    }

    fun clearNotifications() {
        viewModelScope.launch {
            repository.clearNotifications()
        }
    }

    // --- FRIENDSHIP EXECUTIONS ---
    fun sendFriendRequest(email: String) {
        if (email.trim().isEmpty()) return
        viewModelScope.launch {
            // Check if exists
            val code = email.substringBefore("@")
            val name = if (code.length > 3) "المستخدم $code" else "رفيق الدرب"
            repository.insertFriendship(
                Friendship(
                    email = email,
                    name = name,
                    avatarType = Random().nextInt(5) + 1,
                    dailyProgress = 0.0f,
                    streak = 0,
                    todayStatus = "لم يبدأ",
                    lastActivity = "طلب متابعة مرسل وبانتظار الموافقة صراحة",
                    isAccepted = false,
                    isIncoming = false
                )
            )
            addFriendEmailInput.value = ""
            // Notify
            repository.insertNotification(
                NotificationEntity(text = "تم إرسال طلب متابعة بنجاح إلى $email", type = "INFO")
            )
        }
    }

    fun acceptFriend(friend: Friendship) {
        viewModelScope.launch {
            repository.updateFriendship(friend.copy(isAccepted = true, lastActivity = "متصل - وافق على المتابعة المتبادلة"))
            repository.insertNotification(
                NotificationEntity(text = "قبلت طلب المتابعة مع ${friend.name}، يمكنه الآن رؤية نسبة إنجازك.", type = "CHEER")
            )
        }
    }

    fun declineOrDeleteFriend(friendId: Int) {
        viewModelScope.launch {
            repository.deleteFriendship(friendId)
        }
    }

    fun sendCheerMessage(friendName: String, msg: String) {
        viewModelScope.launch {
            repository.insertNotification(
                NotificationEntity(text = "أرسلت رسالة تشجيعية إلى $friendName: '$msg'", type = "CHEER")
            )
        }
    }

    // --- GROUP EXECUTIONS ---
    fun createGroup(name: String, desc: String) {
        if (name.trim().isEmpty()) return
        viewModelScope.launch {
            val randomCode = "GRP" + (10000 + Random().nextInt(90000)).toString()
            repository.insertGroup(
                GroupEntity(
                    name = name,
                    description = desc,
                    inviteCode = randomCode,
                    membersCount = 1,
                    avgCommitment = 0.00f
                )
            )
            newGroupNameInput.value = ""
            newGroupDescInput.value = ""
            // notification
            repository.insertNotification(
                NotificationEntity(text = "تم إنشاء المجموعة '$name' بنجاح! شارك الكود $randomCode لبدء المنافسة.", type = "INFO")
            )
        }
    }

    fun joinGroup(inviteCode: String) {
        if (inviteCode.trim().isEmpty()) return
        viewModelScope.launch {
            // Simulator join
            val codeClean = inviteCode.trim().uppercase()
            repository.insertGroup(
                GroupEntity(
                    name = "مجموعة تحدي الأوراد ($codeClean)",
                    description = "مجموعة جديدة تلتزم بالسنن والصلوات والورد القرآني التنافسي.",
                    inviteCode = codeClean,
                    membersCount = 4,
                    avgCommitment = 0.65f
                )
            )
            joinGroupCodeInput.value = ""
            repository.insertNotification(
                NotificationEntity(text = "انضممت بنجاح إلى المجموعة الروحيّة وحساب متوسط الالتزام التنافسي.", type = "INFO")
            )
        }
    }

    // --- LIBRARY ACTIONS ---
    fun selectSurah(surah: Surah?) {
        activeSurah.value = surah
        if (surah == null) {
            stopQuranVerse()
        } else {
            // Check if verses are empty or contains placeholder text
            val isPlaceholder = surah.verses.size <= 1 && (surah.verses.isEmpty() || surah.verses[0].contains("محتوى السورة") || surah.verses[0].contains("متاح"))
            if (isPlaceholder) {
                fetchSurahVerses(surah.id)
            }
        }
    }

    fun fetchSurahVerses(surahId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            isLoadingVerses.value = true
            audioErrorMessage.value = null
            try {
                val url = "https://api.alquran.cloud/v1/surah/$surahId"
                val client = OkHttpClient.Builder()
                    .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                val request = Request.Builder()
                    .url(url)
                    .get()
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseStr = response.body?.string() ?: ""
                    val obj = JSONObject(responseStr)
                    val dataObj = obj.getJSONObject("data")
                    val ayahsArr = dataObj.getJSONArray("ayahs")
                    val versesList = mutableListOf<String>()
                    val basmalah1 = "بِسۡمِ ٱللَّهِ ٱلرَّحۡمَـٰنِ ٱلرَّحِيمِ"
                    val basmalah2 = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"

                    for (i in 0 until ayahsArr.length()) {
                        var text = ayahsArr.getJSONObject(i).getString("text").trim()
                        if (i == 0 && surahId != 1) {
                            if (text.startsWith(basmalah1)) {
                                text = text.substring(basmalah1.length).trim()
                            } else if (text.startsWith(basmalah2)) {
                                text = text.substring(basmalah2.length).trim()
                            } else {
                                val idx1 = text.indexOf("ٱلرَّحِيمِ")
                                val idx2 = text.indexOf("الرَّحِيمِ")
                                if (idx1 in 0..60) {
                                    text = text.substring(idx1 + "ٱلرَّحِيمِ".length).trim()
                                } else if (idx2 in 0..60) {
                                    text = text.substring(idx2 + "الرَّحِيمِ".length).trim()
                                }
                            }
                        }
                        versesList.add(text)
                    }

                    // Look up existing surah to preserve other values like name, type, versesCount
                    val originalSurah = LibraryData.quranSurahs.find { it.id == surahId }
                    val name = originalSurah?.name ?: dataObj.getString("name")
                    val type = originalSurah?.type ?: (if (dataObj.getString("revelationType") == "Meccan") "مكية" else "مدنية")
                    val versesCount = originalSurah?.versesCount ?: dataObj.getInt("numberOfAyahs")

                    val updatedSurah = Surah(
                        id = surahId,
                        name = name,
                        type = type,
                        versesCount = versesCount,
                        verses = versesList
                    )

                    // If activeSurah is still the same selected surah ID, update it
                    if (activeSurah.value?.id == surahId) {
                        activeSurah.value = updatedSurah
                    }
                } else {
                    audioErrorMessage.value = "تعذر تحميل آيات السورة من الشبكة (رمز ${response.code})"
                }
            } catch (e: Exception) {
                audioErrorMessage.value = "فشل في الاتصال بالشبكة لجلب آيات السورة. تأكد من اتصال الإنترنت."
            } finally {
                isLoadingVerses.value = false
            }
        }
    }

    fun selectAzkarCategory(category: String?) {
        activeAzkarCategory.value = category
        // Reset counts mapping
        val items = when (category) {
            "MORNING" -> LibraryData.morningAzkar
            "EVENING" -> LibraryData.eveningAzkar
            "POST_PRAYER" -> LibraryData.postPrayerAzkar
            else -> emptyList()
        }
        val map = mutableMapOf<Int, Int>()
        items.forEachIndexed { index, zikrItem ->
            map[index] = zikrItem.count
        }
        activeZikrTapCounts.value = map
    }

    fun tapZikr(index: Int) {
        val currentMap = activeZikrTapCounts.value.toMutableMap()
        val count = currentMap[index] ?: 0
        if (count > 0) {
            currentMap[index] = count - 1
            activeZikrTapCounts.value = currentMap
            // If it reached zero, log completion if registered as task
            if (count == 1) {
                // finished
                val categoryName = when (activeAzkarCategory.value) {
                    "MORNING" -> "قراءة أذكار الصباح"
                    "EVENING" -> "قراءة أذكار المساء"
                    else -> null
                }
                if (categoryName != null) {
                    // search task and complete
                    viewModelScope.launch {
                        val tasks = repository.allTasks.first()
                        val relevantTask = tasks.find { it.name == categoryName }
                        if (relevantTask != null) {
                            toggleWorshipCompletion(relevantTask, true, 1)
                        }
                    }
                }
            }
        }
    }

    fun selectBook(book: HadithBook?) {
        activeBook.value = book
    }

    // --- AUDIO PLAYER INTERFACE ---
    fun playQuranVerse(surahId: Int, verseIndex: Int) {
        // If they click on already playing/paused verse, let's toggle it!
        if (currentPlayingSurahId.value == surahId && currentPlayingVerseIndex.value == verseIndex) {
            togglePlayPause()
            return
        }

        // Use the current activeSurah state if it matches the requested surah ID,
        // since it might have the dynamically loaded rich verses instead of placeholders!
        val surah = if (activeSurah.value?.id == surahId) {
            activeSurah.value
        } else {
            LibraryData.quranSurahs.find { it.id == surahId }
        } ?: return
        if (verseIndex < 0 || verseIndex >= surah.verses.size) {
            stopQuranVerse()
            return
        }

        currentPlayingSurahId.value = surahId
        currentPlayingVerseIndex.value = verseIndex
        audioState.value = AudioPlaybackState.LOADING
        audioErrorMessage.value = null

        try {
            mediaPlayer?.release()
            mediaPlayer = android.media.MediaPlayer().apply {
                val verseNum = verseIndex + 1
                val fileCode = String.format(Locale.US, "%03d%03d", surahId, verseNum)
                val folder = selectedReciter.value.folder
                val url = "https://everyayah.com/data/$folder/$fileCode.mp3"
                
                setDataSource(url)
                setOnPreparedListener {
                    it.start()
                    audioState.value = AudioPlaybackState.PLAYING
                }
                setOnCompletionListener {
                    val nextIndex = verseIndex + 1
                    if (nextIndex < surah.verses.size) {
                        playQuranVerse(surahId, nextIndex)
                    } else {
                        stopQuranVerse()
                    }
                }
                setOnErrorListener { _, _, _ ->
                    audioState.value = AudioPlaybackState.ERROR
                    audioErrorMessage.value = "تعذر تشغيل الصوت للورد المبارك"
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            audioState.value = AudioPlaybackState.ERROR
            audioErrorMessage.value = "حدث خطأ أثناء تحميل الصوت: ${e.localizedMessage}"
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        if (audioState.value == AudioPlaybackState.PLAYING) {
            player.pause()
            audioState.value = AudioPlaybackState.PAUSED
        } else if (audioState.value == AudioPlaybackState.PAUSED) {
            player.start()
            audioState.value = AudioPlaybackState.PLAYING
        }
    }

    fun stopQuranVerse() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        currentPlayingSurahId.value = null
        currentPlayingVerseIndex.value = null
        audioState.value = AudioPlaybackState.IDLE
        audioErrorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
