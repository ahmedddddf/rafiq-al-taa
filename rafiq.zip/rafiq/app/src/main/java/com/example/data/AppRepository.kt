package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val dao: AppDao) {

    val userProfile: Flow<UserProfile?> = dao.getUserProfile()
    val allTasks: Flow<List<DailyTask>> = dao.getAllTasks()
    val allCompletions: Flow<List<TaskCompletion>> = dao.getAllCompletions()
    val allFriends: Flow<List<Friendship>> = dao.getAllFriends()
    val allGroups: Flow<List<GroupEntity>> = dao.getAllGroups()
    val allAchievements: Flow<List<Achievement>> = dao.getAllAchievements()
    val allNotifications: Flow<List<NotificationEntity>> = dao.getAllNotifications()

    fun getCompletionsByDate(date: String): Flow<List<TaskCompletion>> = dao.getCompletionsByDate(date)

    suspend fun insertUserProfile(profile: UserProfile) {
        dao.insertUserProfile(profile)
    }

    suspend fun insertTask(task: DailyTask): Long {
        return dao.insertTask(task)
    }

    suspend fun deleteTask(taskId: Int) {
        dao.deleteTaskById(taskId)
        dao.deleteCompletionsByTaskId(taskId)
    }

    suspend fun insertCompletion(completion: TaskCompletion) {
        dao.insertCompletion(completion)
    }

    suspend fun insertFriendship(friend: Friendship) {
        dao.insertFriendship(friend)
    }

    suspend fun updateFriendship(friend: Friendship) {
        dao.updateFriendship(friend)
    }

    suspend fun deleteFriendship(id: Int) {
        dao.deleteFriendship(id)
    }

    suspend fun insertGroup(group: GroupEntity) {
        dao.insertGroup(group)
    }

    suspend fun deleteGroup(id: Int) {
        dao.deleteGroup(id)
    }

    suspend fun insertNotification(notification: NotificationEntity) {
        dao.insertNotification(notification)
    }

    suspend fun clearNotifications() {
        dao.clearAllNotifications()
    }
}
